"""In-process Laue indexing interface."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from time import perf_counter
from typing import Iterable, Mapping

import numpy as np

from ._liblaue import Geometry, NativeCrystal, ffi, get_library
from .crystal import Crystal, load_crystal
from .errors import IndexingError, InputError
from .lau_dataclasses.atom import Atom as StepAtom
from .lau_dataclasses.hkls import HKLs
from .lau_dataclasses.indexing import Indexing
from .lau_dataclasses.pattern import Pattern as StepPattern
from .lau_dataclasses.recipLattice import RecipLattice
from .lau_dataclasses.step import Step
from .lau_dataclasses.xtl import Xtl
from .xml_utils import write_combined_xml, write_step_xml


def _raise_native_error(status: int, stage: str, message: str) -> None:
    detail = f"{stage} failed: {message}"
    if status == 2:
        raise MemoryError(detail)
    if status == 1:
        raise InputError(detail)
    raise IndexingError(detail)


PEAK_DTYPE = np.dtype([
    ("fit_x", np.float64),
    ("fit_y", np.float64),
    ("intens", np.float64),
    ("integral", np.float64),
    ("hwhm_x", np.float64),
    ("hwhm_y", np.float64),
    ("tilt", np.float64),
    ("chisq", np.float64),
    ("background", np.float64),
    ("qhat", np.float64, (3,)),
])


@dataclass(frozen=True)
class PeakParams:
    boxsize: int = 5
    max_rfactor: float = 2.0
    min_size: int = 3
    min_separation: int = 10
    threshold: float | None = 100.0
    threshold_ratio: float = 4.0
    peak_shape: str = "Lorentzian"
    max_peaks: int = 50
    smooth: bool = False
    detect_binning: int = 1


@dataclass(frozen=True)
class FrameMetadata:
    """Optional experiment provenance for an in-memory frame."""

    title: str | None = None
    sample_name: str | None = None
    user_name: str | None = None
    beamline: str | None = None
    scan_number: int | None = None
    date_exposed: str | None = None
    beam_bad: int | None = None
    ccd_shutter: str | None = None
    light_on: int | None = None
    mono_mode: str | None = None
    sample_position: tuple[float, float, float] | None = None
    energy_kev: float | None = None
    hutch_temperature: float | None = None
    sample_distance: float | None = None
    detector_id: str | None = None
    exposure_seconds: float | None = None

    def as_dict(self) -> dict[str, object]:
        return {
            name: value for name, value in self.__dict__.items() if value is not None
        }


@dataclass(frozen=True)
class Pattern:
    euler_deg: np.ndarray
    rotation: np.ndarray
    recip: np.ndarray
    goodness: float
    rms_error_deg: float
    hkl: np.ndarray
    pk_index: np.ndarray
    err_deg: np.ndarray
    energy_kev: np.ndarray
    pred_intens: np.ndarray

    @property
    def n_indexed(self) -> int:
        return len(self.pk_index)


@dataclass(frozen=True)
class IndexParams:
    kev_max_calc: float = 30.0
    kev_max_test: float = 35.0
    angle_tolerance_deg: float = 0.12
    cone_deg: float = 72.0
    hkl_prefer: tuple[int, int, int] = (0, 0, 1)
    max_data: int = 250


@dataclass(frozen=True)
class FrameResult:
    peaks: np.ndarray
    patterns: tuple[Pattern, ...]
    threshold_used: float
    total_sum: float
    sum_above_threshold: float
    num_above_threshold: int
    peaksearch_seconds: float
    indexing_seconds: float
    metadata: Mapping[str, object] = field(default_factory=dict)
    input_image: str | None = None
    image_shape: tuple[int, int] = (0, 0)
    start: tuple[int, int] = (0, 0)
    group: tuple[int, int] = (1, 1)
    depth: float | None = None
    image: np.ndarray | None = field(default=None, repr=False, compare=False)
    _step: Step | None = field(default=None, repr=False, compare=False)

    @property
    def indexed(self) -> bool:
        return bool(self.patterns)

    @property
    def n_peaks(self) -> int:
        return len(self.peaks)

    @property
    def n_indexed(self) -> int:
        return sum(pattern.n_indexed for pattern in self.patterns)

    @property
    def n_patterns(self) -> int:
        return len(self.patterns)

    @property
    def elapsed_seconds(self) -> float:
        return self.peaksearch_seconds + self.indexing_seconds

    @property
    def indexed_peak_indices(self) -> np.ndarray:
        if not self.patterns:
            return np.empty(0, dtype=np.int32)
        return np.unique(np.concatenate([pattern.pk_index for pattern in self.patterns]))

    @property
    def unindexed_peak_indices(self) -> np.ndarray:
        return np.setdiff1d(np.arange(self.n_peaks), self.indexed_peak_indices)

    def to_step(self) -> Step:
        if self._step is None:
            raise RuntimeError("FrameResult has no XML step snapshot")
        return deepcopy(self._step)

    def write_xml(self, path: str | Path) -> None:
        write_step_xml(self.to_step(), str(path))


def index_frame(
    frame: np.ndarray | str | Path,
    *,
    geometry: str | Path | Geometry,
    crystal: str | Path | Crystal | None = None,
    peak_params: PeakParams | None = None,
    index_params: IndexParams | None = None,
    detector_index: int = 0,
    detector_id: str | None = None,
    cosmic_filter: bool = False,
    **kwargs,
) -> FrameResult:
    """Index one frame without explicitly constructing an Indexer."""
    return Indexer(
        geometry,
        crystal,
        peak_params=peak_params,
        index_params=index_params,
        detector_index=detector_index,
        detector_id=detector_id,
        cosmic_filter=cosmic_filter,
    ).index(frame, **kwargs)


class Indexer:
    """Reusable in-process processor, separate from the legacy ``index()`` API.

    Peak search, pixel-to-q conversion, and crystal indexing run through
    ``liblaue`` without intermediate files or subprocesses.
    """

    def __init__(
        self,
        geo_file: str | Path | Geometry,
        crystal_file: str | Path | Crystal | None = None,
        *,
        peak_params: PeakParams | None = None,
        index_params: IndexParams | None = None,
        detector_index: int = 0,
        detector_id: str | None = None,
        cosmic_filter: bool = False,
    ):
        self.geo_file = geo_file.path if isinstance(geo_file, Geometry) else Path(geo_file)
        self.crystal_model = (
            load_crystal(crystal_file) if isinstance(crystal_file, (str, Path)) else crystal_file
        )
        self.crystal_file = Path(self.crystal_model.source) if self.crystal_model and self.crystal_model.source else None
        self.geometry = geo_file if isinstance(geo_file, Geometry) else Geometry(self.geo_file)
        self.crystal = NativeCrystal.create(self.crystal_model) if self.crystal_model is not None else None
        self.peak_params = peak_params or PeakParams()
        self.index_params = index_params or IndexParams()
        self._validate_params()
        if len(self.index_params.hkl_prefer) != 3:
            raise InputError("hkl_prefer must contain exactly three integers")
        if self.index_params.max_data < 2:
            raise InputError("max_data must be at least 2")
        if detector_id is not None:
            detector_index = self.geometry.find_detector(detector_id)
            if detector_index < 0:
                raise InputError(f"detector_id {detector_id!r} is not present in the geometry")
        if not 0 <= detector_index < self.geometry.detector_count:
            raise InputError(f"detector_index must be between 0 and {self.geometry.detector_count - 1}")
        self.detector_index = detector_index
        self.detector = self.geometry.detector(detector_index)
        self.detector_id = detector_id
        self.cosmic_filter = cosmic_filter
        self._xtl = self._crystal_to_xtl(self.crystal_model) if self.crystal_model else Xtl()

    def _validate_params(self) -> None:
        peak = self.peak_params
        indexing = self.index_params
        if peak.boxsize < 1 or peak.min_size < 1 or peak.min_separation < 1 or peak.max_peaks < 1:
            raise InputError("peak sizes, separation, and max_peaks must be positive")
        if peak.max_rfactor <= 0:
            raise InputError("max_rfactor must be positive")
        if peak.peak_shape.upper()[:1] not in {"L", "G"}:
            raise InputError("peak_shape must be Lorentzian or Gaussian")
        if peak.detect_binning != 1:
            raise InputError("only exact detect_binning=1 is currently supported")
        if min(indexing.kev_max_calc, indexing.kev_max_test, indexing.angle_tolerance_deg, indexing.cone_deg) <= 0:
            raise InputError("indexing energy and angle parameters must be positive")

    def process(
        self,
        frame: np.ndarray | str | Path,
        *,
        start: tuple[int, int] = (0, 0),
        group: tuple[int, int] = (1, 1),
        depth: float | None = None,
        mask: np.ndarray | None = None,
        metadata: FrameMetadata | Mapping[str, object] | None = None,
        keep_image: bool = True,
    ) -> FrameResult:
        """Process one NumPy frame or HDF5 file without subprocesses."""
        input_image = None
        file_detector_id = None
        supplied_metadata = metadata.as_dict() if isinstance(metadata, FrameMetadata) else dict(metadata or {})
        if isinstance(frame, (str, Path)):
            input_image = str(frame)
            source, file_metadata, file_processing = self._read_h5_frame(frame)
            file_detector_id = file_metadata.get("detector_id")
            supplied_metadata = {**file_metadata, **supplied_metadata}
            start = file_processing.get("start", start)
            group = file_processing.get("group", group)
            depth = file_processing.get("depth", depth)
        else:
            source = np.asarray(frame)
        if source.ndim != 2 or source.dtype != np.uint16:
            raise InputError(
                f"frame must be a 2D uint16 array; received shape={source.shape}, dtype={source.dtype}"
            )
        image = np.ascontiguousarray(source)
        if (
            len(start) != 2
            or len(group) != 2
            or not all(isinstance(value, (int, np.integer)) for value in (*start, *group))
            or min(start) < 0
            or min(group) < 1
        ):
            raise InputError("start must be two nonnegative integers and group two positive integers")
        end_x = start[0] + image.shape[1] * group[0]
        end_y = start[1] + image.shape[0] * group[1]
        if end_x > self.detector.nx or end_y > self.detector.ny:
            raise InputError(
                f"frame ROI start={start}, shape={image.shape}, group={group} exceeds "
                f"detector bounds {self.detector.nx}x{self.detector.ny}"
            )
        if file_detector_id is not None and file_detector_id != self.detector.detector_id:
            raise InputError(
                f"frame detector_id {file_detector_id!r} does not match selected detector "
                f"{self.detector.detector_id!r}"
            )
        if depth is not None and not np.isfinite(depth):
            raise InputError("depth must be finite when provided")

        mask_buffer = None
        mask_pointer = ffi.NULL
        if mask is not None:
            mask_buffer = np.ascontiguousarray(mask, dtype=np.uint8)
            if mask_buffer.shape != image.shape:
                raise InputError(f"mask shape {mask_buffer.shape} does not match frame shape {image.shape}")
            mask_pointer = ffi.from_buffer("unsigned char[]", mask_buffer)

        params = ffi.new("laue_peak_params *")
        params.boxsize = self.peak_params.boxsize
        params.max_rfactor = self.peak_params.max_rfactor
        params.min_size = self.peak_params.min_size
        params.min_separation = self.peak_params.min_separation
        params.threshold = np.nan if self.peak_params.threshold is None else self.peak_params.threshold
        params.threshold_ratio = (
            4.0 if self.peak_params.threshold_ratio == -1 else self.peak_params.threshold_ratio
        )
        params.peak_shape = 1 if self.peak_params.peak_shape.upper().startswith("G") else 0
        params.max_peaks = self.peak_params.max_peaks
        params.smooth = self.peak_params.smooth
        params.mask = mask_pointer
        params.detect_binning = self.peak_params.detect_binning

        library = get_library()
        result = ffi.new("laue_frame_result *")
        pixels = ffi.from_buffer("unsigned short[]", image)
        peaksearch_started = perf_counter()
        status = library.laue_find_peaks(pixels, image.shape[1], image.shape[0], params, result)
        peaksearch_seconds = perf_counter() - peaksearch_started
        if status:
            message = ffi.string(result.message).decode(errors="replace")
            library.laue_frame_result_free(result)
            _raise_native_error(status, "peak search", message)

        try:
            result.startx, result.starty = start
            result.groupx, result.groupy = group
            result.depth = np.nan if depth is None else depth
            status = library.laue_pixels_to_q(self.geometry._handle, self.detector_index, result)
            if status:
                _raise_native_error(
                    status,
                    "pixel-to-q conversion",
                    ffi.string(result.message).decode(errors="replace"),
                )

            indexing_started = perf_counter()
            if self.crystal is not None and result.n_peaks > 1:
                index_params = ffi.new("laue_index_params *")
                index_params.kev_max_calc = self.index_params.kev_max_calc
                index_params.kev_max_test = self.index_params.kev_max_test
                index_params.angle_tolerance_deg = self.index_params.angle_tolerance_deg
                index_params.cone_deg = self.index_params.cone_deg
                for index, value in enumerate(self.index_params.hkl_prefer):
                    index_params.hkl_prefer[index] = value
                index_params.max_data = self.index_params.max_data
                status = library.laue_index(self.crystal._handle, index_params, result)
                if status:
                    _raise_native_error(
                        status,
                        "orientation indexing",
                        ffi.string(result.message).decode(errors="replace"),
                    )

            indexing_seconds = perf_counter() - indexing_started

            peaks = np.empty(result.n_peaks, dtype=PEAK_DTYPE)
            for index in range(result.n_peaks):
                peak = result.peaks[index]
                peaks[index] = (
                    peak.fit_x, peak.fit_y, peak.intens, peak.integral,
                    peak.hwhm_x, peak.hwhm_y, peak.tilt, peak.chisq,
                    peak.background, tuple(peak.qhat),
                )
            patterns = []
            for index in range(result.n_patterns):
                pattern = result.patterns[index]
                count = pattern.n_indexed
                patterns.append(Pattern(
                    euler_deg=np.asarray(list(pattern.euler_deg)),
                    rotation=np.asarray([list(row) for row in pattern.rotation]),
                    recip=np.asarray([list(row) for row in pattern.recip]),
                    goodness=pattern.goodness,
                    rms_error_deg=pattern.rms_error_deg,
                    hkl=np.asarray([pattern.hkl[i] for i in range(3 * count)], dtype=np.int32).reshape((-1, 3)),
                    pk_index=np.asarray([pattern.pk_index[i] for i in range(count)], dtype=np.int32),
                    err_deg=np.asarray([pattern.err_deg[i] for i in range(count)]),
                    energy_kev=np.asarray([pattern.energy_kev[i] for i in range(count)]),
                    pred_intens=np.asarray([pattern.pred_intens[i] for i in range(count)]),
                ))
            frame_result = FrameResult(
                peaks=peaks,
                patterns=tuple(patterns),
                threshold_used=result.threshold_used,
                total_sum=result.total_sum,
                sum_above_threshold=result.sum_above_threshold,
                num_above_threshold=result.num_above_threshold,
                peaksearch_seconds=peaksearch_seconds,
                indexing_seconds=indexing_seconds,
                metadata=supplied_metadata,
                input_image=input_image,
                image_shape=image.shape,
                start=start,
                group=group,
                depth=depth,
                image=image if keep_image else None,
            )
            object.__setattr__(frame_result, "_step", self._to_step(frame_result))
            return frame_result
        finally:
            library.laue_frame_result_free(result)

    def index(self, frame: np.ndarray | str | Path, **kwargs) -> FrameResult:
        """Index one frame. This is the preferred public method."""
        return self.process(frame, **kwargs)

    def index_many(
        self, frames: Iterable[np.ndarray | str | Path], *, keep_images: bool = False
    ) -> list[FrameResult]:
        """Index frames in order while reusing parsed geometry and crystal data."""
        return [self.index(frame, keep_image=keep_images) for frame in frames]

    def process_many(self, frames: Iterable[np.ndarray | str | Path]) -> list[FrameResult]:
        """Compatibility alias for :meth:`index_many`."""
        return self.index_many(frames)

    def replace(self, **changes) -> "Indexer":
        """Return an Indexer with validated replacement configuration."""
        values = {
            "geo_file": self.geo_file,
            "crystal_file": self.crystal_model,
            "peak_params": self.peak_params,
            "index_params": self.index_params,
            "detector_index": self.detector_index,
            "cosmic_filter": self.cosmic_filter,
        }
        values.update(changes)
        return type(self)(**values)

    def write_xml(self, result: FrameResult, path: str | Path) -> None:
        write_step_xml(result.to_step(), str(path))

    def write_many_xml(self, results: Iterable[FrameResult], path: str | Path) -> None:
        write_combined_xml([result.to_step() for result in results], str(path))

    @staticmethod
    def _read_h5_frame(
        path: str | Path,
    ) -> tuple[np.ndarray, dict[str, object], dict[str, object]]:
        try:
            import h5py
        except ImportError as error:
            raise ImportError("h5py is required when Indexer.process receives a file path") from error

        def scalar(source, name, default=None):
            if name not in source:
                return default
            value = source[name][()]
            if isinstance(value, np.ndarray):
                value = value.flat[0]
            if isinstance(value, bytes):
                return value.decode("utf-8")
            return value.item() if isinstance(value, np.generic) else value

        with h5py.File(path, "r") as source:
            image = source["entry1/data/data"][...]
            shutter = scalar(source, "entry1/microDiffraction/CCDshutter")
            position = tuple(
                scalar(source, name) for name in (
                    "entry1/sample/sampleX", "entry1/sample/sampleY", "entry1/sample/sampleZ"
                )
            )
            metadata = FrameMetadata(
                title=scalar(source, "entry1/title"),
                sample_name=scalar(source, "entry1/sample/name"),
                user_name=scalar(source, "entry1/user/name"),
                beamline=scalar(source, "Facility/facility_beamline"),
                scan_number=scalar(source, "entry1/scanNum"),
                date_exposed=source.attrs["file_time"].decode("utf-8")
                    if "file_time" in source.attrs and isinstance(source.attrs["file_time"], bytes)
                    else source.attrs.get("file_time"),
                beam_bad=scalar(source, "entry1/microDiffraction/BeamBad"),
                ccd_shutter=("out" if shutter else "in") if shutter is not None else None,
                light_on=scalar(source, "entry1/microDiffraction/LightOn"),
                mono_mode=scalar(source, "entry1/microDiffraction/MonoMode"),
                sample_position=position if all(value is not None for value in position) else None,
                energy_kev=scalar(source, "entry1/sample/incident_energy"),
                hutch_temperature=scalar(source, "entry1/microDiffraction/HutchTemperature"),
                sample_distance=scalar(source, "entry1/sample/distance"),
                detector_id=scalar(source, "entry1/detector/ID"),
                exposure_seconds=scalar(source, "entry1/detector/exposure"),
            ).as_dict()
            processing = {
                "start": (
                    scalar(source, "entry1/detector/startx", 0),
                    scalar(source, "entry1/detector/starty", 0),
                ),
                "group": (
                    scalar(source, "entry1/detector/binx", 1),
                    scalar(source, "entry1/detector/biny", 1),
                ),
            }
        return image, metadata, processing

    @staticmethod
    def _crystal_to_xtl(crystal: Crystal) -> Xtl:
        cell = crystal.cell
        xtl = Xtl(
            structureDesc=crystal.name,
            xtalFileName=crystal.source,
            SpaceGroup=crystal.space_group,
            latticeParameters=" ".join(str(value) for value in (
                cell.a, cell.b, cell.c, cell.alpha, cell.beta, cell.gamma
            )),
            lengthUnit=cell.unit,
        )
        for number, atom in enumerate(crystal.atoms, start=1):
            xtl.atoms.append(StepAtom(
                n=number,
                symbol=atom.symbol,
                label=atom.label or atom.symbol,
                values=" ".join(str(value) for value in atom.position),
            ))
        return xtl

    def _to_step(self, result: FrameResult) -> Step:
        metadata = result.metadata
        step = Step()
        names = {
            "title": "title",
            "sample_name": "sampleName",
            "user_name": "userName",
            "beamline": "beamline",
            "scan_number": "scanNum",
            "date_exposed": "dateExposed",
            "beam_bad": "beamBad",
            "ccd_shutter": "CCDshutter",
            "light_on": "lightOn",
            "mono_mode": "monoMode",
            "energy_kev": "energy",
            "hutch_temperature": "hutchTemperature",
            "sample_distance": "sampleDistance",
        }
        for source, destination in names.items():
            if source in metadata:
                setattr(step, destination, metadata[source])
        if "sample_position" in metadata:
            step.Xsample, step.Ysample, step.Zsample = metadata["sample_position"]
        step.depth = "nan" if result.depth is None else str(result.depth)
        step.detector.inputImage = result.input_image
        step.detector.detectorID = metadata.get("detector_id")
        step.detector.exposure = metadata.get("exposure_seconds")
        step.detector.Ny, step.detector.Nx = result.image_shape
        step.detector.totalSum = result.total_sum
        step.detector.sumAboveThreshold = result.sum_above_threshold
        step.detector.numAboveThreshold = result.num_above_threshold
        step.detector.cosmicFilter = self.cosmic_filter
        step.detector.geoFile = str(self.geo_file)
        roi = step.detector.roi
        roi.startx, roi.starty = result.start
        roi.groupx, roi.groupy = result.group
        roi.endx = result.start[0] + (step.detector.Nx - 1) * result.group[0]
        roi.endy = result.start[1] + (step.detector.Ny - 1) * result.group[1]

        peak_data = step.detector.peaksXY
        peak_data.peakProgram = "liblaue"
        peak_data.minwidth = self.peak_params.min_size / 4.0
        peak_data.threshold = result.threshold_used
        peak_data.thresholdRatio = self.peak_params.threshold_ratio
        peak_data.maxRfactor = self.peak_params.max_rfactor
        peak_data.maxwidth = self.peak_params.boxsize * 1.5
        peak_data.maxCentToFit = self.peak_params.boxsize
        peak_data.boxsize = self.peak_params.boxsize
        peak_data.NpeakMax = self.peak_params.max_peaks
        peak_data.minSeparation = self.peak_params.min_separation
        peak_data.peakShape = self.peak_params.peak_shape
        peak_data.Npeaks = result.n_peaks
        peak_data.executionTime = result.peaksearch_seconds
        for peak in result.peaks:
            peak_data.addPeak(*[str(peak[name]) for name in (
                "fit_x", "fit_y", "intens", "integral", "hwhm_x", "hwhm_y", "tilt", "chisq"
            )])
            peak_data.addQVector(*(str(value) for value in peak["qhat"]))

        indexing = Indexing(
            indexProgram="liblaue",
            Nindexed=result.n_indexed,
            Npeaks=result.n_peaks,
            NpatternsFound=len(result.patterns),
            keVmaxCalc=self.index_params.kev_max_calc,
            keVmaxTest=self.index_params.kev_max_test,
            angleTolerance=self.index_params.angle_tolerance_deg,
            cone=self.index_params.cone_deg,
            hklPrefer=" ".join(str(value) for value in self.index_params.hkl_prefer),
            executionTime=result.indexing_seconds,
            xtl=deepcopy(self._xtl),
        )
        for number, source in enumerate(result.patterns):
            reciprocal = RecipLattice(
                astar=" ".join(str(value) for value in source.recip[:, 0]),
                bstar=" ".join(str(value) for value in source.recip[:, 1]),
                cstar=" ".join(str(value) for value in source.recip[:, 2]),
            )
            hkls = HKLs(
                h=[str(value) for value in source.hkl[:, 0]],
                k=[str(value) for value in source.hkl[:, 1]],
                l=[str(value) for value in source.hkl[:, 2]],
                PkIndex=[str(value) for value in source.pk_index],
            )
            indexing.patterns.append(StepPattern(
                num=number,
                rms_error=source.rms_error_deg,
                goodness=source.goodness,
                Nindexed=source.n_indexed,
                recip_lattice=reciprocal,
                hkl_s=hkls,
            ))
        step.indexing = indexing
        return step
